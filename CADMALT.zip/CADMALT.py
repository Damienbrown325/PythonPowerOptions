import subprocess
import place
import tkinter as tk

root= tk.Tk() 

root.title("Power Options")
   
canvas1 = tk.Canvas(root, width = 350, height = 250) 
canvas1.pack()


def start_batch(): 
       subprocess.call([r"C:\CADMALT\BATCH\shutdown.bat"])

def start_batch_2(): 
       subprocess.call([r"C:\CADMALT\BATCH\restart.bat"])

def start_batch_3(): 
       subprocess.call([r"C:\CADMALT\BATCH\hibernate.bat"])

def my_site_launcher():
    import webbrowser
    strURL = "https://damienbrown15.wixsite.com/mysite"
    webbrowser.open(strURL, new=2) 

button1 = tk.Button (root, text='Shut Down ',command=start_batch)
canvas1.create_window(170, 80, window=button1)

button2 = tk.Button (root, text='Restart ',command=start_batch_2)
canvas1.create_window(170, 120, window=button2)

button3 = tk.Button (root, text='Hibernate ',command=start_batch_3)
canvas1.create_window(170, 160, window=button3)

button4 = tk.Button (root, text='Exit ',command=root.destroy)
canvas1.create_window(170, 200, window=button4)

button5 = tk.Button (root, text='Go to my website ',command=my_site_launcher)
canvas1.create_window(170, 240, window=button5)

root.iconbitmap(r'C:\CADMALT\ico\standby.ico')
root.mainloop()

